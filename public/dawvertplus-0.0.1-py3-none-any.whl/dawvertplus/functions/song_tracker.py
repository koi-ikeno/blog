# SPDX-FileCopyrightText: 2023 SatyrDiamond
# SPDX-License-Identifier: GPL-3.0-or-later

from dawvertplus.functions import note_convert
from dawvertplus.functions import auto
from dawvertplus.functions import note_mod
from dawvertplus.functions import data_bytes
#from dawvertplus.functions_tracks import tracks_m
from dawvertplus.functions_tracks import tracks_mi

global used_instruments_num
used_instruments_num = []

global used_instruments
used_instruments = []

global multi_used_instruments
multi_used_instruments = []

global slidediv
slidediv = 16

# ----------------------------------------------------------------------------------------------------

def getfineval(value):
    volslidesplit = data_bytes.splitbyte(value)
    volslideout = 0
    if volslidesplit[0] == 0 and volslidesplit[1] == 0: volslideout = 0
    elif volslidesplit[0] == 15 and volslidesplit[1] == 15: volslideout = volslidesplit[0]/16
    elif volslidesplit[0] == 0 and volslidesplit[1] == 15: volslideout = -15
    elif volslidesplit[0] == 0 and volslidesplit[1] != 0: volslideout = volslidesplit[1]*-1
    elif volslidesplit[0] != 0 and volslidesplit[1] == 0: volslideout = volslidesplit[0]
    elif volslidesplit[0] == 15 and volslidesplit[1] != 15: volslideout = (volslidesplit[0]*-1)/16
    elif volslidesplit[0] != 15 and volslidesplit[1] == 15: volslideout = volslidesplit[0]/16
    return volslideout

# ----------------------------------------------------------------------------------------------------

def get_used_instruments(): return used_instruments
def get_used_instruments_num(): return used_instruments_num

def get_channeldata_inside_pattern(patterntable_single, channel):
    output_table = []
    position = 0
    patternsize = len(patterntable_single)
    while position < patternsize:
        output_table.append([patterntable_single[position][0],patterntable_single[position][1][channel]])
        position += 1
    return output_table

def entire_song_channel(patterntable_all, channel, orders):
    entire_song_channel_out = []
    for pattern_num in orders:
        patterntable_single = get_channeldata_inside_pattern(patterntable_all[pattern_num], channel)
        for patternrow in patterntable_single:
            entire_song_channel_out.append([patternrow[0], patternrow[1]])
    return entire_song_channel_out

def calcslidepower(slidepower, current_speed):
    if current_speed == 0: current_speed = 6
    divfirst = slidepower
    divsec = ((8/current_speed))
    return (divfirst/divsec)-(slidepower/8)

def calcbendpower_up(inval, current_speed):
    if current_speed == 0: current_speed = 6
    global slidediv
    return inval/(slidediv/current_speed)

def calcbendpower_down(inval, current_speed):
    if current_speed == 0: current_speed = 6
    global slidediv
    return (inval*-1)/(slidediv/current_speed)

def make_placement_data(pos, dur, nl, current_channelnum):
    if nl != []:
        single_placement = {}
        single_placement['position'] = pos
        single_placement['duration'] = dur
        single_placement['type'] = 'instruments'
        single_placement['notelist'] = nl
        single_placement['name'] = 'Chan #' + str(current_channelnum+1)
        return single_placement
    else: return None

def convertchannel2notelist(patterntable_channel, startinststr, current_channelnum):
    patterntable_channel[0][0]['firstrow'] = 1

    output_placements = []
    pos_global = 0
    pos_pl = 0
    pos_note = 0

    cvpj_notelist = []

    pos_note = 0
    lastinst = None
    plactive = False
    note_held = 0
    skip_rows = 0
    plpos = 0

    current_speed = 6
    slidecontval = 0

    slidediv = 16

    slidekey = 0
    slidepower = 1

    for notecommand in patterntable_channel:

        if notecommand[1][1] != None:  lastinst = notecommand[1][1]
        notecommand[1][1] = lastinst

        if 'firstrow' in notecommand[0]:
            if plactive == True:
                placedata = make_placement_data(plpos, pos_pl, cvpj_notelist, current_channelnum+1)
                if placedata != None: output_placements.append(placedata)
                cvpj_notelist = []
                plactive = False
            pos_pl = 0
            skip_rows = 0
            note_held = 0
            plpos = pos_global
            plactive = True

        if skip_rows == 0:

            instparam = notecommand[1][2]

            if notecommand[1][0] == None:
                pass 
            elif notecommand[1][0] == 'Fade' or notecommand[1][0] == 'Cut' or notecommand[1][0] == 'Off':
                note_held = 0
                pos_note = 0
            elif 'slide_to_note' not in instparam:
                note_mod.pitchmod2point_init()

                tone_porta_speed = 0
                tone_porta_key = 0

                note_held = 1
                pos_note = -1
                cvpj_note = {'position':pos_pl, 'duration':0, 'key':notecommand[1][0]}

                if 'vol' in notecommand[1][2]: cvpj_note['vol'] = notecommand[1][2]['vol']
                if 'pan' in notecommand[1][2]: cvpj_note['pan'] = notecommand[1][2]['pan']
                cvpj_note['instrument'] = startinststr+str(notecommand[1][1])

                instnumid = notecommand[1][1]
                instid = startinststr+str(notecommand[1][1])
                if instnumid != None:
                    if instnumid not in used_instruments_num: used_instruments_num.append(instnumid)
                    if instid not in used_instruments: used_instruments.append(instid)

                cvpj_notelist.append(cvpj_note)

            if pos_note != None: pos_note += 1

            pos_pl += 1
            pos_global += 1

            if 'speed' in notecommand[0]: 
                current_speed = notecommand[0]['speed']

            if note_held == 1:
                if notecommand[1][0] == None:
                    if 'slide_down' in instparam: 
                        note_mod.pitchmod2point(cvpj_notelist[-1], pos_note, 0, 1, 1, instparam['slide_down'])
                    if 'slide_up' in instparam: 
                        note_mod.pitchmod2point(cvpj_notelist[-1], pos_note, 0, 1, 1, instparam['slide_up'])

                if 'note_cut' in instparam:
                    cvpj_notelist[-1]['duration'] += instparam['note_cut']/current_speed
                    note_held = 0
                    pos_note = 0
                else:
                    cvpj_notelist[-1]['duration'] += 1

            if len(cvpj_notelist) != 0:
                if 'slide_down_cont' in instparam: 
                    if instparam['slide_down_cont'] != 0: slidecontval = instparam['slide_down_cont']
                    note_mod.pitchmod2point(cvpj_notelist[-1], pos_note, 0, 1, 1, slidecontval)
                if 'slide_up_cont' in instparam:  
                    if instparam['slide_up_cont'] != 0: slidecontval = instparam['slide_up_cont']
                    note_mod.pitchmod2point(cvpj_notelist[-1], pos_note, 0, 1, 1, slidecontval)
                if 'slide_to_note' in instparam: 
                    if notecommand[1][0] != None and notecommand[1][0] != 'Off': slidekey = notecommand[1][0]
                    if instparam['slide_to_note'] != 0: slidepower = instparam['slide_to_note'] 
                    note_mod.pitchmod2point(cvpj_notelist[-1], pos_note, 1, 1, slidepower, slidekey)

            #print(str(pos_global).ljust(5), end='')
            #print(str(pos_pl).ljust(5), end='')
            #print(str(pos_note).ljust(5), end='')
            #print(str(len(cvpj_notelist)).ljust(5), end='')
            #print(str(note_held).ljust(2), end='')
            #print(str(skip_rows).ljust(2), end='')
            #print(str(notecommand).ljust(40))
            #print(cvpj_notelist)
            #time.sleep(0.1)

        if 'break_to_row' in notecommand[0]:
            skip_rows = 1
            note_held = 0

    placedata = make_placement_data(plpos, pos_pl, cvpj_notelist, current_channelnum+1)
    if placedata != None:
        output_placements.append(placedata)
    return output_placements

def song2playlist(patterntable_all, number_of_channels, order_list, startinststr, color):
    projL_playlist = {}
    for current_channelnum in range(number_of_channels):
        print('[song-tracker] Converting Channel ' + str(current_channelnum+1))
        note_convert.timednotes2notelistplacement_track_start()
        channelsong = entire_song_channel(patterntable_all,current_channelnum,order_list)
        placements = convertchannel2notelist(channelsong, startinststr, current_channelnum)
        projL_playlist[str(current_channelnum+1)] = {}
        projL_playlist[str(current_channelnum+1)]['color'] = color
        projL_playlist[str(current_channelnum+1)]['name'] = 'Channel ' + str(current_channelnum+1)
        projL_playlist[str(current_channelnum+1)]['placements_notes'] = placements
    return projL_playlist

def get_len_table(patterntable_all, orders):
    lentable = []
    for pattern_num in orders:
        patterntable_single = patterntable_all[pattern_num]
        outlen = 0
        parserow = 1
        for patternrow in patterntable_single:
            patglobalparam = patternrow[0]
            if parserow == 1:
                outlen += 1
            if 'break_to_row' in patglobalparam:
                if patglobalparam['break_to_row'] == 0:
                    parserow = 0
        lentable.append(outlen)
    return lentable

def tempo_auto(patterntable_all, orders, speed, tempo):
    skip_rows = 0
    tempo_pos = 0

    current_speed = speed
    current_tempo = tempo
    tempovalue = current_tempo/(current_speed/6)

    tempo_placements = []
    placement_data = None
    speed_changed = False

    for pattern_num in orders:
        for patternrow in patterntable_all[pattern_num]:
            if 'firstrow' in patternrow[0]:
                if placement_data != None:
                    placement_data['points'] = placement_points
                    placement_data['duration'] = placement_duration
                    if placement_points != []: tempo_placements.append(placement_data)
                    placement_data = None
                skip_rows = 0
                placement_data = {}
                placement_currentpos = 0
                placement_position = tempo_pos
                placement_duration = 0
                placement_points = []
                placement_data['position'] = placement_position

            if 'speed' in patternrow[0]:
                current_speed = patternrow[0]['speed']
                speed_changed = True

            if 'tempo' in patternrow[0]:
                current_tempo = patternrow[0]['tempo']
                speed_changed = True

            if speed_changed == True:
                if current_speed/6 != 0: tempovalue = current_tempo/(current_speed/6)
                placement_points.append({"position": placement_currentpos, "value": tempovalue, "type": 'instant'})
                speed_changed = False

            if skip_rows == 0:
                tempo_pos += 1
                placement_duration += 1
                placement_currentpos += 1

            if 'break_to_row' in patternrow[0]:
                if patternrow[0]['break_to_row'] == 0:
                    skip_rows = 1

    if placement_data != None:
        placement_data['points'] = placement_points
        placement_data['duration'] = placement_duration

        if placement_points != []: tempo_placements.append(placement_data)

    for tempo_placement in tempo_placements:
        auto.resize(tempo_placement)

    return tempo_placements

def get_multi_used_instruments(): return multi_used_instruments

def multi_get_len_table(i_rows, i_patterns, i_orders, i_chantype):
    patternlengths = []
    patternlengths_num = 0
    for i_order in i_orders:
        lensong = len(i_orders[i_order])
        if lensong > patternlengths_num: patternlengths_num = lensong

    for _ in range(patternlengths_num):
        patternlengths.append(i_rows)

    for channum in range(len(i_chantype)):
        s_patterns = i_patterns[channum]
        s_orders = i_orders[channum]
        curpatnum = 0
        for patnum in s_orders:
            s_pattern = s_patterns[patnum]
            rownum = 0
            for row in s_pattern:
                rownum += 1
                if 'skip_pattern' in row[0]: 
                    if patternlengths[curpatnum] > rownum: patternlengths[curpatnum] = rownum
                    break
            curpatnum += 1

    return patternlengths



def multi_convert(cvpj_l, i_rows, i_patterns, i_orders, i_chantype, i_len_table):
    plnum = 1

    cvpj_l['playlist'] = {}
    cvpj_l_playlist = cvpj_l['playlist']

    cvpj_l['notelistindex'] = {}
    cvpj_l_notelistindex = cvpj_l['notelistindex']

    for channum in range(len(i_chantype)):
        s_chantype = i_chantype[channum]
        s_patterns = i_patterns[channum]
        s_orders = i_orders[channum]

        tracks_mi.playlist_add(cvpj_l, channum+1)
        tracks_mi.playlist_visual(cvpj_l, channum+1, name=s_chantype)

        for patnum in s_patterns:
            s_pattern = s_patterns[patnum]

            NLP = convertchannel2notelist(s_pattern, s_chantype+'_', channum)
            used_instruments = get_used_instruments()

            for used_instrument in used_instruments:
                ui_split = used_instrument.split('_')
                if ui_split not in multi_used_instruments: multi_used_instruments.append(ui_split)

            if NLP != []:
                patid = str(channum)+'_'+str(patnum)

                tracks_mi.notelistindex_add(cvpj_l, patid, NLP[0]['notelist'])
                tracks_mi.notelistindex_visual(cvpj_l, patid, name=s_chantype+' ('+str(patnum)+')')


        curpatnum = 0
        curpos = 0
        for s_order in s_orders:
            if s_order in s_patterns:
                cvpj_l_placement = {}
                cvpj_l_placement['position'] = curpos
                cvpj_l_placement['duration'] = i_len_table[curpatnum]
                cvpj_l_placement['fromindex'] = str(channum)+'_'+str(s_order)
                tracks_mi.add_pl(cvpj_l, str(channum+1), 'notes', cvpj_l_placement)
            curpos += i_len_table[curpatnum]
            curpatnum += 1

    #print(multi_used_instruments)




class patterndata:
    def __init__(self, number_of_channels):
        self.patterndata = {}
        self.num_chans = number_of_channels

    def pattern_add(self, num, rows):
        s_patdata = []
        for _ in range(rows):
            s_patdata.append([{}, [[None, None, {}] for _ in range(self.num_chans)]])
        self.patterndata[num] = s_patdata

    def cell_data(self, n_pat, n_row, n_chan, c_note, c_inst, c_partype, c_parval):
        if n_pat in self.patterndata:
            if n_row < len(self.patterndata[n_pat]):
                if n_chan < self.num_chans:
                    patdata = self.patterndata[n_pat][n_row][1][n_chan]
                    if c_note != None: patdata[0] = c_note
                    if c_inst != None: patdata[1] = c_note
                    if c_partype != None: patdata[2][c_partype] = c_parval
